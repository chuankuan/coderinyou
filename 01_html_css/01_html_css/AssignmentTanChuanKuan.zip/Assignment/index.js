var fred=['fred','flinstone','fred@gmail.com',50];

console.log('length=', fred.length);

// for (var count=0 ; count<fred.length ; count++){
/* for(var i in fred){
    if(i== 0)
        console.log('First name: ', fred[i])
else if(i==1)
        console.log('Last name: ', fred[i])
else if (i==2)
        console.log('Email: ', fred[i])
else
        console.log('Age: ', fred[i]);
   
} */

function createEmoji(imageName){
    //Create image - not in DOM yet
    var imgElem = document.createElement('img');

    //Decorate the element
    imgElem.setAttribute('src', index_smile.jpg);
    imgElem.classList.add('Emojieye');
    return(imgElem);

//Find a place to attach element

}

var hereELem = document.body.querySelector('#here');





